# Author: AIMPED
# Date: 2024-Feb-17
# Copyright: AIMPED
# Description: Version file for AIMPED


__version__ = "0.2.5"
